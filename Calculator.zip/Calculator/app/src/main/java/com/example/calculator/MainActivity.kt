package com.example.calculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val price= findViewById<EditText>(R.id.price)
        val quantity=findViewById<EditText>(R.id.quantity)
        val total=findViewById<Button>(R.id.total)
        val display=findViewById<TextView>(R.id.display)

        total.setOnClickListener()
        {
            val getPrice:Float= price.text.toString().toFloat()
            val getQuantity:Float= quantity.text.toString().toFloat()
            val getTotal:Float= getQuantity * getPrice

            display.text=getTotal.toString()
        }

    }
}